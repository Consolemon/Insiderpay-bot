
import telebot
from telebot import types

API_TOKEN = 'ТВОЙ_ТОКЕН_ЗДЕСЬ'
ADMIN = '@Nicellls'
ADDRESS = 'TFNMna9XLz3BfhK9DAZh9bc5dHVtbbtxGR'

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start'])
def start(m):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("📦 Сделать заказ", "💸 Оплатить", "🛠 Связаться")
    bot.send_message(m.chat.id, "Привет! Выбери действие:", reply_markup=markup)

@bot.message_handler(func=lambda m: m.text=="📦 Сделать заказ")
def order(m):
    msg = bot.send_message(m.chat.id, "Опиши заказ:")
    bot.register_next_step_handler(msg, process_order)

def process_order(m):
    text = f"📦 Заказ от @{m.from_user.username or 'неизвестный'}:
{m.text}"
    bot.send_message(m.chat.id, "✅ Отправлено!")
    bot.send_message(ADMIN, text)

@bot.message_handler(func=lambda m: m.text=="💸 Оплатить")
def pay(m):
    msg = f"💸 Оплати на TRC20 USDT:
`{ADDRESS}`
Пришли скрин."
    bot.send_message(m.chat.id, msg, parse_mode='Markdown')

@bot.message_handler(content_types=['photo'])
def photo(m):
    bot.send_photo(ADMIN, m.photo[-1].file_id, caption=f"💸 Оплата от @{m.from_user.username}")
    bot.send_message(m.chat.id, "✅ Скрин получен. Спасибо!")

@bot.message_handler(func=lambda m: m.text=="🛠 Связаться")
def contact(m):
    bot.send_message(m.chat.id, f"Связь: {ADMIN}")

bot.polling()
    